Non-Record Derivative Submission - PR #1851 / PR #1855 Lineage
val_bpb = X.XXXXX (2-run mean) | ~XX.XX MB | 8xH100 SXM 80GB

Summary
This is a non-record derivative/ablation submission based on the PR #1851 / PR #1855 lineage.

Due to issues with runpod compute avalibility, I was not able to fully measure the outcome of the run.

It does not claim a new leaderboard record. The purpose of this package is to report a last-minute experimental fork that adds three modifications to the existing SOTA-lineage codebase:


Frozen projection / frozen MLP component in layer 7
Spellgram/Spellingbee: a legal hash-based n-gram memory at layer 0 / embedding entry
An inhibitory layer in the middle of the network, on layer 5
The final modified runs landed slightly below the current SOTA, so this is submitted as a transparent non-record architecture/ablation result.

Modified Build Results
These are runs of the modified build described in this folder.

Seed	Post-TTT BPB	Artifact (bytes)	Eval Time	Notes
SEED1	X.XXXXXXXX	XX,XXX,XXX	XXX.Xs	Modified build
SEED2	X.XXXXXXXX	XX,XXX,XXX	XXX.Xs	Modified build
Mean	X.XXXXX			
All artifacts < 16,000,000 bytes [OK]
Eval/training timing intended to comply with the 600s budget [OK]

Only two independent runs were completed before the deadline due to compute constraints.

Modified Build Log Files
train_seedSEED1_modified.log
train_seedSEED2_modified.log
Baseline / Lineage Reference
For context, this work derives from the following PR #1851 / PR #1855 lineage results. These numbers are included only as attribution and comparison, not as claims for this submission.

Seed	Post-TTT BPB	Artifact (bytes)	Eval Time	Source
42	1.06128183	15,952,086	519.5s	PR #1851 (@aquariouseworkman)
314	1.06086831	15,952,419	525.6s	Reproduction (@Christopher-Lee-McClendon)
1234	1.06220261	15,952,690	479.6s	Reproduction (@Christopher-Lee-McClendon)
Mean +/- Std	1.06145 +/- 0.00068			
All artifacts < 16,000,000 bytes [OK]
All eval times < 600s [OK]

Original Lineage Log Files
train_seed42_pr1851_original.log - Seed 42 from PR #1851 by @aquariouseworkman
train_seed314_original.log - Seed 314 reproduction by @Christopher-Lee-McClendon
train_seed1234_original.log - Seed 1234 reproduction by @Christopher-Lee-McClendon
Compliance Re-run Evidence From Lineage
The original lineage runs used GPTQ_RESERVE_SECONDS=0.5, which resulted in the training loop running until approximately 599.6s. GPTQ Hessian collection accesses training data and adds approximately 3.5s, potentially extending past the 600s budget.

To confirm compliance, the lineage seeds were re-run with GPTQ_RESERVE_SECONDS=8.0, ensuring the training loop ends around 592s and GPTQ Hessians complete around 595.5s, within the 600s budget. The only code change was the timing margin; there was no ML change.

These lineage compliance results are included for provenance and comparison only. They are not presented as the result of this modified submission.

Seed	Post-TTT BPB (re-run)	Train Time	GPTQ Ends By	Artifact (bytes)
42	1.06083288	592.1s	~595.5s [OK]	15,949,701
314	1.06090748	592.0s	~595.5s [OK]	15,951,777
1234	1.06248776	592.1s	~595.5s [OK]	15,951,968
Mean +/- Std	1.06141 +/- 0.00093			
No statistically significant difference was observed between the original lineage mean of 1.06145 and the re-run mean of 1.06141. The delta is -0.00004, within 1-sigma noise. This supports the conclusion that the GPTQ reserve setting had negligible impact on model quality.

Lineage Re-run Log Files
train_seed42_rerun_gptq8s.log
train_seed314_rerun_gptq8s.log
train_seed1234_rerun_gptq8s.log
What Changed in the Lineage Re-run
GPTQ_RESERVE_SECONDS changed from 0.5 to 8.0, causing the training loop to end earlier for GPTQ headroom.
Serialization was reordered so the artifact is written immediately after GPTQ, before pre-quant diagnostic evaluation.
Timing instrumentation was added for serialize_wallclock and artifact_production_wallclock.
GPTQ Timing Breakdown From Lineage Re-run
Phase	Time	Accesses Training Data?
Training loop with 8s reserve	~592s	Yes
Hessian collection	~3.5s	Yes
Total training-data-access time	~595.5s	< 600s [OK]
Quantization	~10.1s	No, uses cached Hessians
Brotli compression	~65-67s	No, pure I/O
Technique Stack
This package starts from the PR #1851 / PR #1855 lineage and modifies it with three experimental changes.

Inherited Techniques
Technique	Source
Base architecture: 11L, MLP 4x, MuonEq-R	PR #1787 (@nprime06)
SmearGate attention + BOS fix	PR #1797 (@dexhunter) + PR #1851 (@aquariouseworkman)
LQER asymmetric quantization	PR #1797 (@dexhunter)
CaseOps SP8192	PR #1729 (@romeerp)
GPTQ + SP8192	PR #1394 (@clarkkev)
Score-first TTT, 3 phases	PR #549 (@abaybektursun)
BOS bug identification	@cocohearts
Experimental Changes in This Submission
Frozen projection / frozen MLP component in layer 7
Spellgram/Spellingbee: a legal hash-based n-gram memory at layer 0 / embedding entry
Inhibitory layer in the middle of the model, on layer 5
Architecture
The submission follows the PR #1851 / PR #1855 lineage architecture:

11L x 512d x 8H/4KV, MLP 4x, LeakyReLU(0.5)^2, Partial RoPE with 16/64 dims, layerwise LN scale, tied embeddings, logit softcap=30.0. Depth recurrence: layers 3-5 looped x2, activated at frac=0.35. Parallel residuals from layer 8. XSA on all 11 layers. SmearGate window=12.

This modified submission adds:

Frozen projection / frozen MLP component in layer 7
Spellgram/Spellingbee legal n-gram memory at layer 0 / embedding entry
An inhibitory layer in the middle of the network, on layer 5
Reproduction
# Install dependencies
pip install brotli python-minifier

# Prepare CaseOps SP8192 data
python3 prepare_caseops_data.py  # downloads from romeerp/parameter-golf-caseops-v1

# Run training, replacing SEED with the desired seed
SEED=42 \
CASEOPS_ENABLED=1 \
EMBED_BITS=7 \
SMEAR_GATE_ENABLED=1 \
SPARSE_ATTN_GATE_ENABLED=1 \
MIN_LR=0.1 \
EMBED_CLIP_SIGMAS=15.0 \
MLP_CLIP_SIGMAS=12.0 \
GPTQ_RESERVE_SECONDS=8.0 \
PHASED_TTT_NUM_PHASES=3 \
torchrun --standalone --nproc_per_node=8 train_gp