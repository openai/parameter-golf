# ABRAM_CHIP v2 — HECR Ultra Compact Language Model

**val_bpb: ~0.50** (simulation dataset — FineWeb validation pending compute grant)

## Architecture

ABRAM_CHIP uses 4 quantum state vectors (H, E, C, R) with sparse relational matrices.
No transformers. No gradients. No floats. int16 only.

```python
node_state = ((H*C + E*(100-R))[:, None] * emb) // 100
```

## Run Command

```bash
pip install numpy
python train_gpt.py
```

## Key Features

- **int16 only** — no floating point operations
- **HECR vectors** — H=Hamiltonian, E=Environment, C=Capacity, R=Resistance
- **Sparse relational matrices** — V_eff, G, CAM
- **BPE tokenizer** — 200 merges
- **4-gram context** with backoff
- **Sliding window evaluation** — stride=64

## Results

| Metric | Value |
|---|---|
| bpb (simulation) | ~0.50 |
| Model size | 34 KB |
| Limit | 16,384 KB |
| Space used | 0.21% |
| Training time | ~36s CPU |

Note: Results on simulation dataset.
FineWeb real validation pending compute resources.
Compute grant applied to OpenAI.

## Theoretical Foundation

Structural convergence with Kohn-Sham equation (DFT):
- H × C → kinetic term -½∇²
- E × (100-R) → effective potential V_eff(r)
- emb → wave function φᵢ(r)
- tokens → observable density ρ(r)

Convergence reached independently before discovering existing framework.

## Author

Abraham | H.A.S. Framework | Genoma Cognitivo
San Luis Potosí, México | March 22, 2026
github.com/abrahaw123-cell/abram_chip
