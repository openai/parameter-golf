"""
ABRAM_CHIP v2 — Parameter Golf Execution Script
=================================================
Run this script to train and evaluate ABRAM_CHIP.

Usage:
    python train_abram_chip.py

Requirements:
    pip install numpy

Author: Abraham — H.A.S. Framework | Genoma Cognitivo
Date: March 22, 2026
"""

import numpy as np
import math
import re
import os
import json
import time
from collections import defaultdict, Counter

# =========================================================
# CONFIG
# =========================================================
N          = 128
T          = 50
EMB_SIZE   = 64
VOCAB_SIZE = 256
CONTEXTO   = 4
STRIDE     = 64
SEED       = 42

np.random.seed(SEED)

# =========================================================
# HECR VECTORS
# =========================================================
H = np.random.randint(20, 100, N, dtype=np.int16)
E = np.random.randint(10, 60,  N, dtype=np.int16)
C = np.random.randint(30, 100, N, dtype=np.int16)
R = np.random.randint(10, 50,  N, dtype=np.int16)

def sparse_idx(dense, thresh=0.5):
    return [np.where(row > thresh)[0] for row in dense]

V_eff = sparse_idx(np.random.rand(N, N))
G     = sparse_idx(np.random.rand(N, N))
CAM   = sparse_idx(np.random.rand(N, N))

# =========================================================
# EVOLUTION
# =========================================================
def evolve(emb):
    for _ in range(T):
        s = ((H * C + E * (100 - R))[:, None] * emb) // 100
        for i in range(N):
            for j in CAM[i]: s[i] += s[j] // 20
        for i in range(N):
            for j in V_eff[i]:
                for k in G[i]: s[i] += s[j] // 50
        emb = np.clip(s, -32000, 32000).astype(np.int16)
    return emb

# =========================================================
# BPE
# =========================================================
class BPE:
    def __init__(self): self.merges = {}
    def _pairs(self, toks):
        p = Counter()
        for t in toks:
            for i in range(len(t)-1): p[(t[i],t[i+1])] += 1
        return p
    def train(self, texts, n=200):
        words = []
        for t in texts:
            for w in t.lower().split():
                w = re.sub(r'[^a-záéíóúüñ]','',w)
                if len(w)>1: words.append(tuple(w)+('</w>',))
        toks = list(words)
        for n_ in range(n):
            p = self._pairs(toks)
            if not p: break
            best = p.most_common(1)[0][0]
            self.merges[best] = n_
            new = []
            for t in toks:
                nt=[]; i=0
                while i<len(t):
                    if i<len(t)-1 and (t[i],t[i+1])==best: nt.append(t[i]+t[i+1]); i+=2
                    else: nt.append(t[i]); i+=1
                new.append(tuple(nt))
            toks = new
    def tok(self, text):
        out=[]
        for w in text.lower().split():
            w=re.sub(r'[^a-záéíóúüñ]','',w)
            if len(w)>1: out.append(w)
        return out

# =========================================================
# MODEL
# =========================================================
class ABRAMCHIP:
    def __init__(self):
        emb = (np.random.rand(N, EMB_SIZE)*100).astype(np.int16)
        self.emb   = evolve(emb)
        self.bpe   = BPE()
        self.ngram = defaultdict(Counter)
        self.vocab = Counter()

    def train(self, texts):
        self.bpe.train(texts)
        for t in texts:
            toks = self.bpe.tok(t)
            for tok in toks: self.vocab[tok] += 1
            for i in range(len(toks)-CONTEXTO):
                self.ngram[tuple(toks[i:i+CONTEXTO])][toks[i+CONTEXTO]] += 1

    def prob(self, ctx, nxt):
        for n in range(CONTEXTO, 0, -1):
            k = tuple(ctx[-n:])
            if k in self.ngram:
                ops=self.ngram[k]; tot=sum(ops.values())
                return (ops.get(nxt,0)+1)/(tot+len(self.vocab)+1)
        return 1/(len(self.vocab)+1)

    def evaluate(self, texts, stride=STRIDE):
        lp=0; bt=0
        for t in texts:
            toks=self.bpe.tok(t)
            for s in range(0,len(toks)-CONTEXTO,stride):
                ctx=toks[s:s+CONTEXTO]
                if s+CONTEXTO<len(toks):
                    nxt=toks[s+CONTEXTO]
                    lp+=math.log2(self.prob(ctx,nxt))
                    bt+=len(nxt.encode('utf-8'))
        return -lp/bt if bt>0 else float('inf')

    def size_kb(self):
        import sys
        s=self.emb.nbytes+H.nbytes+E.nbytes+C.nbytes+R.nbytes
        for k,v in self.ngram.items(): s+=sys.getsizeof(k)+sys.getsizeof(v)
        return s/1024

    def save(self, path="abram_chip_weights.npz"):
        np.savez_compressed(path, emb=self.emb, H=H, E=E, C=C, R=R)
        print(f"Weights saved: {path} ({os.path.getsize(path)/1024:.1f} KB)")

# =========================================================
# LOAD FINEWEB (if available)
# =========================================================
def load_data():
    try:
        from datasets import load_dataset
        print("Loading FineWeb...")
        ds = load_dataset("HuggingFaceFW/fineweb", name="sample-10BT",
                         split="train", streaming=True, trust_remote_code=True)
        train=[]; val=[]
        for i,ex in enumerate(ds):
            if i<5000: train.append(ex['text'])
            elif i<6000: val.append(ex['text'])
            else: break
        return train, val
    except:
        print("FineWeb unavailable — using simulation data")
        texts = [
            "The history of artificial intelligence began when researchers explored machines.",
            "Climate change represents one of the most significant challenges facing humanity.",
            "The human brain contains billions of neurons giving rise to consciousness.",
            "Quantum computing leverages principles of quantum mechanics to process information.",
            "Language is the primary tool through which humans transmit culture and knowledge.",
            "Evolutionary biology demonstrates that all living organisms share common ancestors.",
            "Social systems emerge from interactions of individuals producing complex behavior.",
            "Cognitive science investigates the nature of mind and intelligence in systems.",
            "Los sistemas complejos emergen de la interacción entre agentes relacionales.",
            "La densidad del comportamiento es lo único observable desde afuera del sistema.",
        ] * 20
        split = int(len(texts)*0.8)
        return texts[:split], texts[split:]

# =========================================================
# MAIN
# =========================================================
if __name__ == "__main__":

    print("\n" + "="*55)
    print("  ABRAM_CHIP v2 — Parameter Golf")
    print("  H.A.S. Framework | Abraham 2026")
    print("="*55 + "\n")

    t0 = time.time()

    train, val = load_data()
    print(f"Train: {len(train)} | Val: {len(val)}\n")

    model = ABRAMCHIP()
    model.train(train)
    model.save()

    bpb = model.evaluate(val)
    kb  = model.size_kb()
    t1  = time.time()

    print(f"\n{'='*45}")
    print(f"  FINAL RESULTS")
    print(f"{'='*45}")
    print(f"  bpb:          {bpb:.4f}")
    print(f"  size:         {kb:.2f} KB")
    print(f"  limit:        16,384 KB")
    print(f"  usage:        {kb/16384*100:.4f}%")
    print(f"  train time:   {t1-t0:.1f}s")
    print(f"{'='*45}\n")

    results = {"bpb": round(bpb,4), "size_kb": round(kb,2),
               "train_time_s": round(t1-t0,1), "author": "Abraham",
               "model": "ABRAM_CHIP v2", "date": "2026-03-22"}

    with open("results.json","w") as f:
        json.dump(results, f, indent=2)
    print("Results saved: results.json")
