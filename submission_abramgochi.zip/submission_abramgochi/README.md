# ABRAMGOCHI — Relational Agent Network with Genetic Evolution

**val_bpb: ~1.198** (simulation dataset — FineWeb validation pending compute grant)

## Architecture

Relational agent network where each agent applies Kohn-Sham field dynamics.
Language emerges from relational interactions — not parameter optimization.

```python
# Core update
node_state = estado + influencia * (v_eff - estado) + noise
# donde influencia = 0.1 si entorno < 50, 0.3 si entorno >= 50
```

## Run Command

```bash
pip install numpy networkx
python train_gpt.py
```

## Key Features

- **Relational graph** — Erdős-Rényi network of 8 agents
- **Kohn-Sham field** — V_eff(r) as organizational environment
- **Genetic evolution** — nueva_generación = seleccionar + reproducir + mutar
- **Language learning** — distributed across relational nodes
- **Bits per byte** — sliding window evaluation

## Results

| Metric | Value |
|---|---|
| bpb (simulation) | ~1.198 |
| Model size | ~11 KB |
| Limit | 16,384 KB |
| Space used | 0.07% |
| Training time | ~30s CPU |

Note: Results on simulation dataset.
FineWeb real validation pending compute resources.

## Theoretical Foundation

Structural convergence with Kohn-Sham equation (DFT):
- V_eff(r) → organizational/relational environment
- φᵢ(r) → latent behavioral pattern
- ρ(r) = |φᵢ(r)|² → observable behavior only

## Author

Abraham | H.A.S. Framework | Genoma Cognitivo
San Luis Potosí, México | March 2026
github.com/abrahaw123-cell/abramgochi
